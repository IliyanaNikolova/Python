znak=input("Въведете знак(+,-,*,/): ")
num1=float(input("Въведете първото число: "))
num2=float(input("Въведете второто число: "))
if znak == '+':
    result = num1 + num2
    print(f"{num1} + {num2} = {result}")
elif znak == '-':
    result= num1 - num2
    print(f"{num1} - {num2} = {result}")
elif znak=='*':
    result = num1 * num2
    print(f"{num1} * {num2} = {result}")
elif znak == '/':
    result= num1/num2
    print(f"{num1} / {num2} = {result}")
else:
    print(f"{znak} не е валиден оператор!!!")